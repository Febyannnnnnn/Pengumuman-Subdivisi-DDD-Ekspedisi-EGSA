# DDD Ekspedisi EGSA 2027 — website reset

## Isi paket
- `index.html`
- `style.css`
- `script.js`
- `assets/` (tempat file font Supply Center)

## Cara pasang di GitHub
1. Buka repository GitHub Pages.
2. Upload/ganti `index.html`, `style.css`, dan `script.js` dengan file dari paket ini.
3. Buat folder `assets` jika belum ada.
4. Letakkan file font `Supply-Center.ttf` di `assets/Supply-Center.ttf`.
5. Commit changes dan tunggu GitHub Pages selesai deploy.

Satoshi dimuat dari Fontshare, jadi perlu koneksi internet.
Supply Center tidak disertakan karena file font harus diunduh/diizinkan oleh pemilik font terlebih dahulu.
Data penempatan yang saat ini dimasukkan di `script.js` hanya nama yang diketahui dari percakapan. Tambahkan data resmi lainnya sebelum digunakan publik.
