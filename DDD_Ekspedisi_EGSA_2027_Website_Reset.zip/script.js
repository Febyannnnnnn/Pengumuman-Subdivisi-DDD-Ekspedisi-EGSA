/*
 * Data penempatan contoh dari informasi yang tersedia.
 * Tambahkan nama anggota lain ke objek placements di bawah.
 */
const placements = {
  "nanda": "Desain",
  "tsaqif": "Desain",
  "fio": "Desain",
  "rafferty": "Dokumentasi",
  "kamal": "Editing",
  "seno": "Editing"
};

const form = document.getElementById("search-form");
const nameInput = document.getElementById("name-input");
const result = document.getElementById("result");

function normalizeName(value) {
  return value
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .trim()
    .toLowerCase()
    .replace(/\s+/g, " ");
}

form.addEventListener("submit", (event) => {
  event.preventDefault();
  const typedName = nameInput.value.trim();
  const key = normalizeName(typedName);
  const matchedKey = Object.keys(placements).find(
    (name) => name === key || key.includes(name) || name.includes(key)
  );

  result.hidden = false;

  if (!typedName) {
    result.innerHTML = `<p>Masukkan nama kamu terlebih dahulu.</p>`;
    return;
  }

  if (matchedKey) {
    const subdivision = placements[matchedKey];
    result.innerHTML = `
      <p class="result-label">HASIL PENEMPATAN</p>
      <h3>Selamat, ${escapeHTML(typedName)}!</h3>
      <p>Kamu ditempatkan di subdivisi</p>
      <h3>${subdivision}</h3>
      <p>Semangat berkarya bersama DDD Ekspedisi EGSA 2027!</p>
    `;
  } else {
    result.innerHTML = `
      <p class="result-label">NAMA BELUM DITEMUKAN</p>
      <h3>Periksa kembali, ya!</h3>
      <p>Nama tersebut belum ada di data penempatan pada halaman ini. Coba gunakan nama panggilan atau hubungi panitia DDD.</p>
    `;
  }
});

function escapeHTML(value) {
  return value.replace(/[&<>"']/g, (char) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  }[char]));
}
